-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-02-2022 a las 18:18:37
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `emlopez`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `autorizacion`
--

CREATE TABLE `autorizacion` (
  `idpermiso` int(11) NOT NULL,
  `nombre_campo` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `autorizacion`
--

INSERT INTO `autorizacion` (`idpermiso`, `nombre_campo`) VALUES
(1, 'Portal'),
(2, 'Usuario'),
(3, 'Ventas'),
(4, 'Compras'),
(5, 'Consulta Ventas'),
(6, 'Consulta Compras'),
(7, 'Almacen');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modelo_calzado`
--

CREATE TABLE `modelo_calzado` (
  `idmodelo` int(11) NOT NULL,
  `cod_modelo` varchar(15) NOT NULL,
  `modelo_descripcion` varchar(80) DEFAULT NULL,
  `modelo_genero` char(1) NOT NULL,
  `modelo_etapah` varchar(8) NOT NULL,
  `imagen` varchar(50) NOT NULL,
  `condicion` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `modelo_calzado`
--

INSERT INTO `modelo_calzado` (`idmodelo`, `cod_modelo`, `modelo_descripcion`, `modelo_genero`, `modelo_etapah`, `imagen`, `condicion`) VALUES
(1, 'codb22', 'cierre al costado - taco 2', 'M', 'JOVEN', '1643936869.png', 0),
(2, 'codb23', 'correa al costado - taco 2', 'M', 'JOVEN', '1643939437.png', 1),
(3, 'codb24', 'pasador frontal - taco 3', 'M', 'JOVEN', '1643939458.png', 1),
(4, 'codb25', 'pasador frontal - alto - taco 2', 'M', 'JOVEN', '1643939483.png', 1),
(5, 'codb26', 'pasador frontal - ergonomico - taco 4', 'M', 'JOVEN', '1643939915.png', 1),
(6, 'codb27', 'pasador frontal - ergonomico - taco 2', 'V', 'JOVEN', '1643939961.png', 1),
(7, 'codb28', 'deportivo', 'V', 'JOVEN', '1643940000.png', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producompra_tbcompra`
--

CREATE TABLE `producompra_tbcompra` (
  `idproducompra_tbcompra` int(11) NOT NULL,
  `idproducto_compra` int(11) NOT NULL,
  `idtbcompra` int(11) NOT NULL,
  `cocantidad` int(11) NOT NULL,
  `coprecio_compra` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto_compra`
--

CREATE TABLE `producto_compra` (
  `idproducto_compra` int(11) NOT NULL,
  `proc_nombre` varchar(80) NOT NULL,
  `proc_marca` varchar(45) DEFAULT NULL,
  `proc_descripcion` text DEFAULT NULL,
  `proc_stock` int(10) NOT NULL,
  `imagen` varchar(50) NOT NULL,
  `proc_estado_producto` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `producto_compra`
--

INSERT INTO `producto_compra` (`idproducto_compra`, `proc_nombre`, `proc_marca`, `proc_descripcion`, `proc_stock`, `imagen`, `proc_estado_producto`) VALUES
(1, 'ojalillos', '', 'un ciento de ojalillos', 0, '1644076062.png', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto_venta`
--

CREATE TABLE `producto_venta` (
  `idProducto_venta` int(11) NOT NULL,
  `idmodelo` int(11) NOT NULL,
  `vtalla` int(2) DEFAULT NULL,
  `vcolor` varchar(30) DEFAULT NULL,
  `vtipo_cantidad` varchar(30) DEFAULT NULL,
  `vcantidad` int(11) DEFAULT NULL,
  `vmonto_unitario` double DEFAULT NULL,
  `vfecha_ingreso` datetime DEFAULT current_timestamp(),
  `vfecha_entrega` datetime DEFAULT NULL,
  `vestado_producto` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `producto_venta`
--

INSERT INTO `producto_venta` (`idProducto_venta`, `idmodelo`, `vtalla`, `vcolor`, `vtipo_cantidad`, `vcantidad`, `vmonto_unitario`, `vfecha_ingreso`, `vfecha_entrega`, `vestado_producto`) VALUES
(1, 3, 39, 'negro', 'pares', 24, 80, '2022-02-02 16:14:26', '2021-12-01 00:00:00', 0),
(2, 6, 39, 'marron', 'pares', 12, 60, '2022-02-02 16:14:26', '2021-12-07 00:00:00', 1),
(3, 7, 40, 'azul', 'pares', 24, 70, '2022-02-02 16:14:26', '2021-12-07 00:00:00', 1),
(4, 5, 38, 'marron', 'pares', 24, 84, '2022-02-02 16:14:26', '2021-12-01 00:00:00', 1),
(5, 2, 37, 'negro', 'pares', 12, 72, '2022-02-02 16:14:26', '2021-12-14 00:00:00', 1),
(6, 3, 38, 'negro', 'pares', 36, 80, '2022-02-02 16:14:26', '2021-12-14 00:00:00', 0),
(7, 1, 39, 'negro', 'pares', 12, 72, '2022-02-02 16:14:26', '2021-12-14 00:00:00', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `produventa_tbventa`
--

CREATE TABLE `produventa_tbventa` (
  `idproduventa_tbventa` int(11) NOT NULL,
  `idtbventa` int(11) NOT NULL,
  `idProducto_venta` int(11) NOT NULL,
  `pvcantidad` int(11) NOT NULL,
  `pvprecio_venta` decimal(12,2) NOT NULL,
  `pvdescuento` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbcompra`
--

CREATE TABLE `tbcompra` (
  `idtbcompra` int(11) NOT NULL,
  `idproveedor` int(11) NOT NULL,
  `idtbusuario` int(11) NOT NULL,
  `ctipo_comprobante` varchar(20) NOT NULL,
  `tbcompra_serie` varchar(10) NOT NULL,
  `tbcompra_numero` varchar(25) NOT NULL,
  `tbc_fecha_emision` datetime NOT NULL,
  `tbc_fecha_recepcion` datetime NOT NULL,
  `tbc_igv` decimal(6,2) NOT NULL,
  `tbc_monto_total` decimal(12,2) NOT NULL,
  `tbc_estado_producto` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbpagos_x_destajo`
--

CREATE TABLE `tbpagos_x_destajo` (
  `idtbpagos_x_destajo` int(11) NOT NULL,
  `idusuario_paga` int(11) NOT NULL,
  `tbpagdescripcion` text DEFAULT NULL,
  `tbpagcolor` varchar(45) DEFAULT NULL,
  `tbpagtalla` varchar(45) DEFAULT NULL,
  `cantidad_pieza_terminada` int(11) DEFAULT NULL,
  `precio_x_docena` double DEFAULT NULL,
  `des_fecha_inicio` datetime DEFAULT NULL,
  `des_fecha_termino` datetime DEFAULT NULL,
  `pago_total_x_destajo` double DEFAULT NULL,
  `idusuario_recibe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbpagos_x_horas`
--

CREATE TABLE `tbpagos_x_horas` (
  `idtbpagos_persona` int(11) NOT NULL,
  `idusuario_paga` int(11) NOT NULL,
  `ph_descripcion` text DEFAULT NULL,
  `cantidad_horas` int(11) DEFAULT NULL,
  `precio_x_horas` double DEFAULT NULL,
  `ph_fecha_inicio` datetime DEFAULT NULL,
  `ph_fecha_termino` datetime DEFAULT NULL,
  `pago_total_x_horas` double DEFAULT NULL,
  `idusuario_recibe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbpersona`
--

CREATE TABLE `tbpersona` (
  `idpersona` int(11) NOT NULL,
  `tipo_persona` varchar(20) NOT NULL,
  `razon_social` varchar(100) NOT NULL,
  `tipo_documento` varchar(10) DEFAULT NULL,
  `documento_identidad` varchar(20) DEFAULT NULL,
  `direccion` varchar(70) DEFAULT NULL,
  `celular` int(20) DEFAULT NULL,
  `whatsapp` varchar(45) DEFAULT NULL,
  `correo_electronico` varchar(60) DEFAULT NULL,
  `fecha_registro` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbpersona`
--

INSERT INTO `tbpersona` (`idpersona`, `tipo_persona`, `razon_social`, `tipo_documento`, `documento_identidad`, `direccion`, `celular`, `whatsapp`, `correo_electronico`, `fecha_registro`) VALUES
(1, 'Proveedor', 'INVERSIONES ALARCON EIRL', 'RUC', '20498232401', 'Calle Pizarro 401 Stan 8 - AREQUIPA', 959976051, '959976051', 'impre_alarcon@hotmail.com', '2022-02-02 23:43:21'),
(2, 'Proveedor', 'ROGUSBEL SAC', 'RUC', '20454638345', 'Jr. La Libertad Mz 16 Lt.I-A - Urb. Pachacutec - Arequipa', 958326406, '958326406', 'rogusbes.sac@hotmail.com', '2022-02-02 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbusuario_autorizacion`
--

CREATE TABLE `tbusuario_autorizacion` (
  `idtbusuario_autorizacion` int(11) NOT NULL,
  `idtbusuario` int(11) NOT NULL,
  `idpermiso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbusuario_autorizacion`
--

INSERT INTO `tbusuario_autorizacion` (`idtbusuario_autorizacion`, `idtbusuario`, `idpermiso`) VALUES
(5, 3, 1),
(6, 3, 3),
(7, 3, 5),
(56, 2, 1),
(57, 2, 3),
(58, 2, 5),
(66, 1, 1),
(67, 1, 2),
(68, 1, 3),
(69, 1, 4),
(70, 1, 5),
(71, 1, 6),
(72, 1, 7),
(73, 4, 1),
(74, 4, 2),
(75, 4, 3),
(76, 4, 4),
(77, 4, 5),
(78, 4, 6),
(79, 4, 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbusuario_empresa`
--

CREATE TABLE `tbusuario_empresa` (
  `idtbusuario` int(11) NOT NULL,
  `unombre` varchar(50) NOT NULL,
  `uapellido` varchar(50) NOT NULL,
  `utipo_documento` varchar(20) NOT NULL,
  `unumero_documento` varchar(20) NOT NULL,
  `ucargo` varchar(50) DEFAULT NULL,
  `udireccion` varchar(70) DEFAULT NULL,
  `ucelular` int(20) DEFAULT NULL,
  `uwhatsapp` varchar(45) DEFAULT NULL,
  `ucorreo_electronico` varchar(60) DEFAULT NULL,
  `login` varchar(20) NOT NULL,
  `clave` varchar(64) NOT NULL,
  `ucod_recuperacion` varchar(6) NOT NULL,
  `ufecha_ingreso` datetime DEFAULT current_timestamp(),
  `imagen` varchar(50) NOT NULL,
  `ucondicion` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbusuario_empresa`
--

INSERT INTO `tbusuario_empresa` (`idtbusuario`, `unombre`, `uapellido`, `utipo_documento`, `unumero_documento`, `ucargo`, `udireccion`, `ucelular`, `uwhatsapp`, `ucorreo_electronico`, `login`, `clave`, `ucod_recuperacion`, `ufecha_ingreso`, `imagen`, `ucondicion`) VALUES
(1, 'CHRISTIAN', 'SEGOVIA GUTARRA', 'DNI', '46786746', '', 'jr. santa isabel 1175 - El tambo - Huancayo', 964510395, '964510395', 'csegovia.gutarra145@gmail.com', 'cristian', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', '', '2022-02-05 00:00:00', '1643905886.jpg', 1),
(2, 'DENNIS DANIEL', 'MALLQUI LOPEZ', 'DNI', '76924990', '', 'AV CIRCUNVALACION 803 SCT:2053 MZT:090 UR :ND , Huancayo - Junin', 980, '980 051 934', 'mallqui_l@gmail.com', 'mallqui', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', '', '0000-00-00 00:00:00', '1643905711.png', 1),
(3, 'JOSE ANTONIO', 'VILLAIZAN ROMANI', 'DNI', '41294088', '', 'Jr. Fernandini 745 - El Tambo', 973928352, '973928352', '', 'villaizan', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c8', '', '2022-02-03 00:00:00', '1643911883.jpg', 1),
(4, 'Administrador', 'A', 'DNI', '46786746', '', '', 0, '', '', 'admin', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', '', '2022-02-05 00:00:00', '1644082299.jpg', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbventa`
--

CREATE TABLE `tbventa` (
  `idtbventa` int(11) NOT NULL,
  `idcliente` int(11) NOT NULL,
  `idtbusuario` int(11) NOT NULL,
  `tipo_comprobante` varchar(20) NOT NULL,
  `tbventa_serie` varchar(10) NOT NULL,
  `tbventa_numero` varchar(25) NOT NULL,
  `fecha_venta` datetime NOT NULL,
  `igv` decimal(6,2) NOT NULL,
  `tasa_igv` int(2) NOT NULL,
  `monto_total` decimal(12,2) NOT NULL,
  `tb_pago_banco_cod_pago` int(11) NOT NULL,
  `estado` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tb_pago_banco`
--

CREATE TABLE `tb_pago_banco` (
  `cod_pago` int(11) NOT NULL,
  `tipo_pago` varchar(20) DEFAULT NULL,
  `cod_operacion` varchar(15) DEFAULT NULL,
  `pago_realizado` double DEFAULT NULL,
  `pago_fecha` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `autorizacion`
--
ALTER TABLE `autorizacion`
  ADD PRIMARY KEY (`idpermiso`);

--
-- Indices de la tabla `modelo_calzado`
--
ALTER TABLE `modelo_calzado`
  ADD PRIMARY KEY (`idmodelo`),
  ADD UNIQUE KEY `cod_modelo_UNIQUE` (`cod_modelo`);

--
-- Indices de la tabla `producompra_tbcompra`
--
ALTER TABLE `producompra_tbcompra`
  ADD PRIMARY KEY (`idproducompra_tbcompra`,`idproducto_compra`,`idtbcompra`),
  ADD KEY `idproducto_compra` (`idproducto_compra`),
  ADD KEY `idtbcompra` (`idtbcompra`);

--
-- Indices de la tabla `producto_compra`
--
ALTER TABLE `producto_compra`
  ADD PRIMARY KEY (`idproducto_compra`);

--
-- Indices de la tabla `producto_venta`
--
ALTER TABLE `producto_venta`
  ADD PRIMARY KEY (`idProducto_venta`,`idmodelo`),
  ADD KEY `idmodelo` (`idmodelo`);

--
-- Indices de la tabla `produventa_tbventa`
--
ALTER TABLE `produventa_tbventa`
  ADD PRIMARY KEY (`idproduventa_tbventa`,`idtbventa`,`idProducto_venta`),
  ADD KEY `idtbventa` (`idtbventa`),
  ADD KEY `idProducto_venta` (`idProducto_venta`);

--
-- Indices de la tabla `tbcompra`
--
ALTER TABLE `tbcompra`
  ADD PRIMARY KEY (`idtbcompra`,`idproveedor`,`idtbusuario`),
  ADD KEY `idproveedor` (`idproveedor`),
  ADD KEY `idtbusuario` (`idtbusuario`);

--
-- Indices de la tabla `tbpagos_x_destajo`
--
ALTER TABLE `tbpagos_x_destajo`
  ADD PRIMARY KEY (`idtbpagos_x_destajo`,`idusuario_paga`,`idusuario_recibe`),
  ADD KEY `idusuario_paga` (`idusuario_paga`),
  ADD KEY `idusuario_recibe` (`idusuario_recibe`);

--
-- Indices de la tabla `tbpagos_x_horas`
--
ALTER TABLE `tbpagos_x_horas`
  ADD PRIMARY KEY (`idtbpagos_persona`,`idusuario_paga`,`idusuario_recibe`),
  ADD KEY `idusuario_paga` (`idusuario_paga`),
  ADD KEY `idusuario_recibe` (`idusuario_recibe`);

--
-- Indices de la tabla `tbpersona`
--
ALTER TABLE `tbpersona`
  ADD PRIMARY KEY (`idpersona`);

--
-- Indices de la tabla `tbusuario_autorizacion`
--
ALTER TABLE `tbusuario_autorizacion`
  ADD PRIMARY KEY (`idtbusuario_autorizacion`,`idtbusuario`,`idpermiso`),
  ADD KEY `idtbusuario` (`idtbusuario`),
  ADD KEY `idpermiso` (`idpermiso`);

--
-- Indices de la tabla `tbusuario_empresa`
--
ALTER TABLE `tbusuario_empresa`
  ADD PRIMARY KEY (`idtbusuario`),
  ADD UNIQUE KEY `username_UNIQUE` (`login`);

--
-- Indices de la tabla `tbventa`
--
ALTER TABLE `tbventa`
  ADD PRIMARY KEY (`idtbventa`,`idcliente`,`idtbusuario`,`tb_pago_banco_cod_pago`),
  ADD KEY `idcliente` (`idcliente`),
  ADD KEY `idtbusuario` (`idtbusuario`),
  ADD KEY `tb_pago_banco_cod_pago` (`tb_pago_banco_cod_pago`);

--
-- Indices de la tabla `tb_pago_banco`
--
ALTER TABLE `tb_pago_banco`
  ADD PRIMARY KEY (`cod_pago`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `autorizacion`
--
ALTER TABLE `autorizacion`
  MODIFY `idpermiso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `modelo_calzado`
--
ALTER TABLE `modelo_calzado`
  MODIFY `idmodelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `producompra_tbcompra`
--
ALTER TABLE `producompra_tbcompra`
  MODIFY `idproducompra_tbcompra` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `producto_compra`
--
ALTER TABLE `producto_compra`
  MODIFY `idproducto_compra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `producto_venta`
--
ALTER TABLE `producto_venta`
  MODIFY `idProducto_venta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `produventa_tbventa`
--
ALTER TABLE `produventa_tbventa`
  MODIFY `idproduventa_tbventa` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbcompra`
--
ALTER TABLE `tbcompra`
  MODIFY `idtbcompra` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbpersona`
--
ALTER TABLE `tbpersona`
  MODIFY `idpersona` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tbusuario_autorizacion`
--
ALTER TABLE `tbusuario_autorizacion`
  MODIFY `idtbusuario_autorizacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT de la tabla `tbusuario_empresa`
--
ALTER TABLE `tbusuario_empresa`
  MODIFY `idtbusuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `tbventa`
--
ALTER TABLE `tbventa`
  MODIFY `idtbventa` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tb_pago_banco`
--
ALTER TABLE `tb_pago_banco`
  MODIFY `cod_pago` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `producompra_tbcompra`
--
ALTER TABLE `producompra_tbcompra`
  ADD CONSTRAINT `producompra_tbcompra_ibfk_1` FOREIGN KEY (`idproducto_compra`) REFERENCES `producto_compra` (`idproducto_compra`),
  ADD CONSTRAINT `producompra_tbcompra_ibfk_2` FOREIGN KEY (`idtbcompra`) REFERENCES `tbcompra` (`idtbcompra`);

--
-- Filtros para la tabla `producto_venta`
--
ALTER TABLE `producto_venta`
  ADD CONSTRAINT `producto_venta_ibfk_1` FOREIGN KEY (`idmodelo`) REFERENCES `modelo_calzado` (`idmodelo`);

--
-- Filtros para la tabla `produventa_tbventa`
--
ALTER TABLE `produventa_tbventa`
  ADD CONSTRAINT `produventa_tbventa_ibfk_1` FOREIGN KEY (`idtbventa`) REFERENCES `tbventa` (`idtbventa`),
  ADD CONSTRAINT `produventa_tbventa_ibfk_2` FOREIGN KEY (`idProducto_venta`) REFERENCES `producto_venta` (`idProducto_venta`);

--
-- Filtros para la tabla `tbcompra`
--
ALTER TABLE `tbcompra`
  ADD CONSTRAINT `tbcompra_ibfk_1` FOREIGN KEY (`idproveedor`) REFERENCES `tbpersona` (`idpersona`),
  ADD CONSTRAINT `tbcompra_ibfk_2` FOREIGN KEY (`idtbusuario`) REFERENCES `tbusuario_empresa` (`idtbusuario`);

--
-- Filtros para la tabla `tbpagos_x_destajo`
--
ALTER TABLE `tbpagos_x_destajo`
  ADD CONSTRAINT `tbpagos_x_destajo_ibfk_1` FOREIGN KEY (`idusuario_paga`) REFERENCES `tbusuario_empresa` (`idtbusuario`),
  ADD CONSTRAINT `tbpagos_x_destajo_ibfk_2` FOREIGN KEY (`idusuario_recibe`) REFERENCES `tbusuario_empresa` (`idtbusuario`);

--
-- Filtros para la tabla `tbpagos_x_horas`
--
ALTER TABLE `tbpagos_x_horas`
  ADD CONSTRAINT `tbpagos_x_horas_ibfk_1` FOREIGN KEY (`idusuario_paga`) REFERENCES `tbusuario_empresa` (`idtbusuario`),
  ADD CONSTRAINT `tbpagos_x_horas_ibfk_2` FOREIGN KEY (`idusuario_recibe`) REFERENCES `tbusuario_empresa` (`idtbusuario`);

--
-- Filtros para la tabla `tbusuario_autorizacion`
--
ALTER TABLE `tbusuario_autorizacion`
  ADD CONSTRAINT `tbusuario_autorizacion_ibfk_1` FOREIGN KEY (`idtbusuario`) REFERENCES `tbusuario_empresa` (`idtbusuario`),
  ADD CONSTRAINT `tbusuario_autorizacion_ibfk_2` FOREIGN KEY (`idpermiso`) REFERENCES `autorizacion` (`idpermiso`);

--
-- Filtros para la tabla `tbventa`
--
ALTER TABLE `tbventa`
  ADD CONSTRAINT `tbventa_ibfk_1` FOREIGN KEY (`idcliente`) REFERENCES `tbpersona` (`idpersona`),
  ADD CONSTRAINT `tbventa_ibfk_2` FOREIGN KEY (`idtbusuario`) REFERENCES `tbusuario_empresa` (`idtbusuario`),
  ADD CONSTRAINT `tbventa_ibfk_3` FOREIGN KEY (`tb_pago_banco_cod_pago`) REFERENCES `tb_pago_banco` (`cod_pago`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
