CREATE DATABASE	emlopez;
use emlopez;

CREATE TABLE autorizacion (
  idpermiso INT NOT NULL auto_increment,
  nombre_campo VARCHAR(40) NOT NULL,
  PRIMARY KEY (idpermiso)
  );
  
CREATE TABLE tbusuario_empresa (
   idtbusuario INT NOT NULL auto_increment,
   unombre VARCHAR(50) NOT NULL,
   uapellido VARCHAR(50) NOT NULL,
   utipo_documento VARCHAR(20) NOT NULL,
   unumero_documento VARCHAR(20) NOT NULL,
   ucargo VARCHAR(50) NULL,
   udireccion VARCHAR(70) NULL,
   ucelular INT(20) NULL,
   uwhatsapp VARCHAR(45),
   ucorreo_electronico VARCHAR(60),
   login VARCHAR(20) NOT NULL,
   clave VARCHAR(64) NOT NULL,
   ucod_recuperacion VARCHAR(6) NOT NULL,
   ufecha_ingreso DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
   imagen VARCHAR(50) NOT NULL,
   ucondicion tinyint(1) NOT NULL,
   PRIMARY KEY (idtbusuario),
   UNIQUE KEY username_UNIQUE (username)
  );
  
  #ALTER TABLE tbusuario_empresa CHANGE uimagen imagen VARCHAR(50) NOT NULL;
  #ALTER TABLE modelo_calzado ADD imagen VARCHAR(50) NOT NULL AFTER modelo_etapah;
  #ALTER TABLE producto_compra CHANGE proc_imagen imagen VARCHAR(50) NOT NULL;
  #ALTER TABLE tbusuario_empresa CHANGE ucontrasena ucontrasena VARCHAR(64) NOT NULL;
  #ALTER TABLE tbusuario_empresa CHANGE username login VARCHAR(20) NOT NULL;
  #ALTER TABLE tbusuario_empresa CHANGE ucontrasena clave VARCHAR(64) NOT NULL;
 
  
CREATE TABLE tbusuario_autorizacion (
  idtbusuario_autorizacion INT NOT NULL auto_increment,
  idtbusuario INT NOT NULL,
  idpermiso INT NOT NULL,
  PRIMARY KEY (idtbusuario_autorizacion,idtbusuario,idpermiso),
  FOREIGN KEY (idtbusuario) REFERENCES tbusuario_empresa(idtbusuario),
  FOREIGN KEY (idpermiso) REFERENCES autorizacion (idpermiso)
  );  

#SELECT CONCAT(unombre," ",uapellido) AS PROVEEDOR FROM tbusuario_empresa;

#SELECT c.idtbcompra,DATE(c.tbc_fecha_emision) as fechaori,c.idproveedor,
#p.razon_social as proveedor, u.idtbusuario, CONCAT(u.unombre,' ',u.uapellido)
# as usuario, c.ctipo_comprobante,c.tbcompra_serie,c.tbcompra_numero,
# c.tbc_igv,c.tbc_monto_total,DATE(c.tbc_fecha_recepcion) as fecharec,
# c.tbc_estado_producto FROM tbcompra c INNER JOIN tbpersona p 
# ON c.idproveedor=p.idpersona INNER JOIN tbusuario_empresa u 
 #ON c.idtbusuario=u.idtbusuario;


CREATE TABLE modelo_calzado (
  idmodelo INT NOT NULL auto_increment,
  cod_modelo VARCHAR(15) NOT NULL,
  modelo_descripcion VARCHAR(80) NULL,
  modelo_genero CHAR(1) NOT NULL,
  modelo_etapah VARCHAR(8) NOT NULL,
  imagen VARCHAR(50) NOT NULL,
  condicion tinyint(1) NOT NULL,
  PRIMARY KEY (idmodelo),
  UNIQUE KEY cod_modelo_UNIQUE (cod_modelo)
  );
  
CREATE TABLE Producto_venta (
  idProducto_venta INT NOT NULL auto_increment,
  idmodelo INT NOT NULL,
  vtalla INT(2) NULL,
  vcolor VARCHAR(30) NULL,
  vtipo_cantidad VARCHAR(30) NULL,
  vcantidad INT NULL,
  vmonto_unitario DOUBLE NULL,
  vfecha_ingreso DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  vfecha_entrega DATETIME NULL,
  vestado_producto tinyint(1) NOT NULL,
  PRIMARY KEY (idProducto_venta, idmodelo),
  FOREIGN KEY (idmodelo) REFERENCES modelo_calzado (idmodelo)
    );
    
CREATE TABLE tb_pago_banco (
  cod_pago INT NOT NULL auto_increment,
  tipo_pago VARCHAR(20) NULL,
  cod_operacion VARCHAR(15) NULL,
  pago_realizado DOUBLE NULL,
  pago_fecha DATETIME NULL,
  PRIMARY KEY (cod_pago)
  );
 
  CREATE TABLE tbpersona (
  idpersona INT NOT NULL auto_increment,
  tipo_persona VARCHAR(20) NOT NULL,
  razon_social VARCHAR(100) NOT NULL,
  tipo_documento VARCHAR(10) NULL,
  documento_identidad VARCHAR(20) NULL,
  direccion VARCHAR(70) NULL,
  celular INT(20) NULL,
  whatsapp VARCHAR(45) NULL,
  correo_electronico VARCHAR(60) NULL,
  fecha_registro DATETIME NULL,
  PRIMARY KEY (idpersona)
  );
  
  CREATE TABLE tbventa (
  idtbventa INT NOT NULL auto_increment,
  idcliente INT NOT NULL,
  idtbusuario INT NOT NULL,
  tipo_comprobante VARCHAR(20) NOT NULL,
  tbventa_serie VARCHAR(10) NOT NULL,
  tbventa_numero VARCHAR(25) NOT NULL,
  fecha_venta DATETIME NOT NULL,
  igv DECIMAL(6,2) NOT NULL,
  tasa_igv INT (2) NOT NULL,
  monto_total DECIMAL(12,2) NOT NULL,
  tb_pago_banco_cod_pago INT NOT NULL,
  estado VARCHAR(20) NOT NULL,
  PRIMARY KEY (idtbventa, idcliente, idtbusuario, tb_pago_banco_cod_pago),
  FOREIGN KEY (idcliente) REFERENCES tbpersona (idpersona),
  FOREIGN KEY (idtbusuario) REFERENCES tbusuario_empresa (idtbusuario),
  FOREIGN KEY (tb_pago_banco_cod_pago) REFERENCES tb_pago_banco (cod_pago)
  );
  
  CREATE TABLE produventa_tbventa (
  idproduventa_tbventa INT NOT NULL auto_increment,
  idtbventa INT NOT NULL,
  idProducto_venta INT NOT NULL,
  pvcantidad INT NOT NULL,
  pvprecio_venta DECIMAL(12,2) NOT NULL,
  pvdescuento DECIMAL(12,2) NOT NULL,
  PRIMARY KEY (idproduventa_tbventa, idtbventa, idProducto_venta),
  FOREIGN KEY (idtbventa) REFERENCES tbventa (idtbventa),
  FOREIGN KEY (idProducto_venta) REFERENCES Producto_venta (idProducto_venta)
  );
  
CREATE TABLE producto_compra (
  idproducto_compra INT NOT NULL auto_increment,
  proc_nombre VARCHAR(80) NOT NULL,
  proc_marca VARCHAR(45) NULL,
  proc_descripcion TEXT NULL,
  stock INT(10) NOT NULL,
  imagen VARCHAR(50) NOT NULL,
  estado VARCHAR(20) NULL,
  PRIMARY KEY (idproducto_compra)
  );
  
  #ALTER TABLE producto_compra CHANGE proc_estado_producto estado VARCHAR(20) NULL;

CREATE TABLE tbcompra (
  idtbcompra INT NOT NULL auto_increment,
  idproveedor INT NOT NULL,
  idtbusuario INT NOT NULL,
  ctipo_comprobante VARCHAR(20) NOT NULL,
  tbcompra_serie VARCHAR(10) NOT NULL,
  tbcompra_numero VARCHAR(25) NOT NULL,
  tbc_fecha_emision DATETIME NOT NULL,
  tbc_fecha_recepcion DATETIME NOT NULL,
  impuesto DECIMAL(6,2) NOT NULL,
  total_compra DECIMAL(12,2) NOT NULL,
  estado VARCHAR(20) NOT NULL,
  PRIMARY KEY (idtbcompra, idproveedor, idtbusuario),
  FOREIGN KEY (idproveedor) REFERENCES tbpersona (idpersona),
  FOREIGN KEY (idtbusuario) REFERENCES tbusuario_empresa (idtbusuario)
  );
  
  #ALTER TABLE tbcompra CHANGE monto_total total_compra DECIMAL(12,2) NOT NULL;
  
  CREATE TABLE producompra_tbcompra (
  idproducompra_tbcompra INT NOT NULL auto_increment,
  idproducto_compra INT NOT NULL,
  idtbcompra INT NOT NULL,
  cantidad INT NOT NULL,
  precio_compra DECIMAL(12,2) NOT NULL,
  PRIMARY KEY (idproducompra_tbcompra, idproducto_compra, idtbcompra),
  FOREIGN KEY (idproducto_compra) REFERENCES producto_compra (idproducto_compra),
  FOREIGN KEY (idtbcompra) REFERENCES tbcompra (idtbcompra)
  );

#ALTER TABLE producompra_tbcompra CHANGE coprecio_compra precio_compra DECIMAL(12,2) NOT NULL;

CREATE TABLE tbpagos_x_horas (
  idtbpagos_persona INT NOT NULL,
  idusuario_paga INT NOT NULL,
  ph_descripcion TEXT NULL,
  cantidad_horas INT NULL,
  precio_x_horas DOUBLE NULL,
  ph_fecha_inicio DATETIME NULL,
  ph_fecha_termino DATETIME NULL,
  pago_total_x_horas DOUBLE NULL,
  idusuario_recibe INT NOT NULL,
  PRIMARY KEY (idtbpagos_persona, idusuario_paga, idusuario_recibe),
  FOREIGN KEY (idusuario_paga) REFERENCES tbusuario_empresa (idtbusuario),
  FOREIGN KEY (idusuario_recibe) REFERENCES tbusuario_empresa (idtbusuario)
  );
 
CREATE TABLE tbpagos_x_destajo (
  idtbpagos_x_destajo INT NOT NULL,
  idusuario_paga INT NOT NULL,
  tbpagdescripcion TEXT NULL,
  tbpagcolor VARCHAR(45) NULL,
  tbpagtalla VARCHAR(45) NULL,
  cantidad_pieza_terminada INT NULL,
  precio_x_docena DOUBLE NULL,
  des_fecha_inicio DATETIME NULL,
  des_fecha_termino DATETIME NULL,
  pago_total_x_destajo DOUBLE NULL,
  idusuario_recibe INT NOT NULL,
  PRIMARY KEY (idtbpagos_x_destajo, idusuario_paga, idusuario_recibe),
  FOREIGN KEY (idusuario_paga) REFERENCES tbusuario_empresa (idtbusuario),
  FOREIGN KEY (idusuario_recibe) REFERENCES tbusuario_empresa (idtbusuario)
  );



